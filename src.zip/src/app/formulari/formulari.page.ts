import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formulari',
  templateUrl: './formulari.page.html',
  styleUrls: ['./formulari.page.scss'],
})
export class FormulariPage implements OnInit {

  nombre;
  tipo;

  constructor() { }

  ngOnInit() {
  }

  addPokemon(){
    console.log(this.tipo);
  }

}
