import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.page.html',
  styleUrls: ['./detail.page.scss'],
})

export class DetailPage implements OnInit {
  id;
  constructor(private route: ActivatedRoute) {
    this.id = this.route.snapshot.paramMap.get("id");
    console.log(this.id);
  }

  ngOnInit() {
  }

  Pokemons =  [{"nombre": "Pikachu",
                "tipo": "eléctrico",
                "icono_tipo": "Icon_Electric.png",
                "img": "Pikachu.png",
                "color": "warning"
              },{"nombre": "Charmander",
                "tipo": "fuego",
                "icono_tipo": "Icon_Fire.png",
                "img": "Charmander.png",
                "color": "secondary"
              },{"nombre": "Squirtle",
                "tipo": "agua",
                "icono_tipo": "Icon_Water.png",
                "img": "Squirtle.png",
                "color": "primary"
              },{"nombre": "Bulbasaur",
                "tipo": "hierba",
                "icono_tipo": "Icon_Grass.png",
                "img": "Bulbasaur.png",
                "color": "succes"
              }];

}
