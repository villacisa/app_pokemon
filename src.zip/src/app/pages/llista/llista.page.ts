import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-llista',
  templateUrl: './llista.page.html',
  styleUrls: ['./llista.page.scss'],
})
export class LlistaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
