import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-llista',
  templateUrl: './llista.page.html',
  styleUrls: ['./llista.page.scss'],
})
export class LlistaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }


  Pokemons =  [{"nombre": "Pikachu",
                "tipo": "eléctrico",
                "icono_tipo": "Icon_Electric.png",
                "img": "Pikachu.png",
                "color": "warning"
              },{"nombre": "Charmander",
                "tipo": "fuego",
                "icono_tipo": "Icon_Fire.png",
                "img": "Charmander.png",
                "color": "secondary"
              },{"nombre": "Squirtle",
                "tipo": "agua",
                "icono_tipo": "Icon_Water.png",
                "img": "Squirtle.png",
                "color": "primary"
              },{"nombre": "Bulbasaur",
                "tipo": "hierba",
                "icono_tipo": "Icon_Grass.png",
                "img": "Bulbasaur.png",
                "color": "succes"
              }];

}
